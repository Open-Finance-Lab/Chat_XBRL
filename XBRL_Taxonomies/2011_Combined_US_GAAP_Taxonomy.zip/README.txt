This zip file contains a local copy of the FASB 2011 US GAAP Taxonomy and SEC 2011 non-gaap taxonomies, 
plus the XBRL US Entry Points.

The XBRL US entry point schemas were created as a convenience to provide single entry points that import
the FASB 2011 US GAAP Taxonomy and the SEC non-gaap taxonomies. These entry points are not part of the 
official FASB 2011 US GAAP Taxonomy or the SEC non-gaap taxonomies.

There are two versions of the XBRL US entry point schemas. The normal version in the "XBRL US Entry 
Point" folder imports the FASB 2011 US GAAP Taxonomy and SEC non-gaap taxonomies from their official 
locations on the FASB and SEC websites. The local version in the "XBRL US Entry Point - LOCAL" 
folder, imports the FASB 2011 Taxonomy from the local copy in the "FASB" folder. The SEC non-gaap
taxonomies are still imported from the SEC's website. A local copy of the SEC 2011 non-gaap taxonomies 
is provided for convenience.